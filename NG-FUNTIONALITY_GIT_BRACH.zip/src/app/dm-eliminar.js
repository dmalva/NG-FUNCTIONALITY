function load(name){
  console.log(name);
}