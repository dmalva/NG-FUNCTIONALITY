import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funtionality',
  templateUrl: './funtionality.component.html',
  styleUrls: ['./funtionality.component.css']
})
export class FuntionalityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
