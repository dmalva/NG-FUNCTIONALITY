export class Names{
  name:string;
  age:number;
}